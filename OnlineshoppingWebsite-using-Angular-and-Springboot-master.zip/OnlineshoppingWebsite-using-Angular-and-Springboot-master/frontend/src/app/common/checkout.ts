export class Checkout {
    firstname:string;
    lastname:string;
    email:string;
    country:string;
    street:string;
    city:string;
    state:string;
    zipcode:number;

}
