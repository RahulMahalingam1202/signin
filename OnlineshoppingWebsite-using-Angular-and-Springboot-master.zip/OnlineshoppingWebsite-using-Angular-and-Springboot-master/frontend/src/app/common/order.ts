export class Order {
    id:number;
    userId:number;
    quantity:number;
    price:number;
    orderOn:Date;
}
