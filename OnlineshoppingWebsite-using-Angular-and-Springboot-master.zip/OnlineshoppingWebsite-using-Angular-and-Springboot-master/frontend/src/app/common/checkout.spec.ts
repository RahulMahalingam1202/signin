import { Checkout } from './checkout';

describe('Checkout', () => {
  it('should create an instance', () => {
    expect(new Checkout()).toBeTruthy();
  });
});
