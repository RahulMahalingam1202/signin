export class Card {
    price:number;
    currency:string;
    method:string;
    intent:string;
    description:string;
    constructor(){}
}
