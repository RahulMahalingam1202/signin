import { NgbPaginationNumberContext } from '@ng-bootstrap/ng-bootstrap/pagination/pagination';

export class User {
    id: string;
    name: string;
    password:string;
    email: string;
    username:string;
    constructor(){}
}