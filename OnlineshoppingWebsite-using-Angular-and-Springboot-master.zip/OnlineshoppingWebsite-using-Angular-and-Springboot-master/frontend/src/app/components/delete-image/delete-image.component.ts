import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-image',
  templateUrl: './delete-image.component.html',
  styleUrls: ['./delete-image.component.css']
})
export class DeleteImageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
