import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footerline',
  templateUrl: './footerline.component.html',
  styleUrls: ['./footerline.component.css']
})
export class FooterlineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
