package com.springboot.demo.entity;

public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}

